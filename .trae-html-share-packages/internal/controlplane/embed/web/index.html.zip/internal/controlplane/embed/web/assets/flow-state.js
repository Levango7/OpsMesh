// flow-state.js — OpsMesh 前端编排层共享状态（由 flow.js 拆分）。
//
// 职责：提供跨功能域共享的 state 对象与 DOM 辅助函数（$/pageRoot）。
// 设计要点：state 为单例，所有子模块共享同一引用。

// ============================================================================
// UI 状态
// ============================================================================

const state = {
  currentTab: 'tickets',
  ticketFilter: { status: '', priority: '', category: '' },
  tickets: [],
  slos: [],
  metricsText: '',
  dashboardOverview: { devices: 0, tasks: 0, alerts: 0, openTickets: 0 },
  // Phase 2 状态
  trafficPolicies: [],
  pipelineTemplates: [],
  pipelineRuns: [],
  argocdApps: [],
  canaryReleases: [],
  selectedCanaryId: null,
  configVersions: [],
  pipelineSubTab: 'templates', // templates | runs | argocd
  // Phase 3 状态
  complianceRules: [],
  complianceReports: [],
  complianceSubTab: 'rules', // rules | scan | audit
  auditEvents: [],
  haStatus: null,
  haInstances: [],
  haHealth: null,
  backups: [],
  haSubTab: 'status', // status | backup
  // Phase 4 状态
  networkDevices: [],
  networkDiscovered: [],
  networkSubTab: 'devices', // devices | discover | config
  networkSelectedDevice: null,
  automationRules: [],
  automationExecutions: [],
  automationSubTab: 'rules', // rules | executions
  automationEditingRule: null,
  // Phase 5 状态
  gatewayRoutes: [],
  gatewayStats: null,
  gatewaySubTab: 'routes', // routes | stats
  gatewayEditingRoute: null,
  webhooks: [],
  webhookSubTab: 'list', // list | deliveries
  webhookEditing: null,
  webhookSelectedId: null,
  scripts: [],
  scriptSubTab: 'list', // list | executions
  scriptEditing: null,
  scriptSelectedId: null,
  // Phase 6 状态（平台化管理）
  tenants: [],
  apikeys: [],
  plugins: [],
  billingPlans: [],
  billingSubs: [],
  billingInvoices: [],
  billingSubTab: 'plans', // plans | subscriptions | invoices
  platformConfig: null,
  platformHealth: null,
  platformMetrics: null,
  // P0 补齐功能域状态
  // 设备管理
  devices: [],
  agents: [],
  devicesSubTab: 'devices', // devices | agents
  // 任务执行
  tasks: [],
  taskFilter: { status: '' },
  // 告警管理
  alerts: [],
  alertFilter: { severity: '', state: '' },
  // 告警规则管理
  alertRules: [],
  alertRulesEngine: [],
  alertSilences: [],
  alertRulesSubTab: 'rules', // rules | engine | silences
  // 批量执行
  batches: [],
  batchDetail: null,
  batchSelectedId: null,
  batchSubTab: 'list', // list | exec | create | status
  // P1 补齐功能域状态
  // 通知管理
  notify: { channels: [], templates: [], loading: false, error: null },
  notifySubTab: 'channels', // channels | templates
  // 日志检索
  logs: { entries: [], total: 0, loading: false, error: null, filter: { query: '', level: '', from: '', to: '', limit: '100' } },
  // 部署中心
  deploys: { list: [], federationList: [], loading: false, error: null },
  deploysSubTab: 'list', // list | federation | create
  // 作业编排
  workflows: { list: [], currentStatus: null, loading: false, error: null, selectedId: null },
  // CMDB
  cmdb: { types: [], items: [], changes: [], loading: false, error: null, selectedType: null },
  cmdbSubTab: 'types', // types | items | changes
  // OS 优化
  osOptimize: { templates: [], loading: false, error: null, selectedId: null },
  // 中间件部署
  middleware: { templates: [], instances: [], loading: false, error: null, selectedId: null },
  middlewareSubTab: 'templates', // templates | instances
  // K8s 集群管理
  k8s: { clusters: [], loading: false, error: null },
  // P2 补齐功能域状态
  // 自动纳管
  provision: { result: null, loading: false, error: null },
  // ChatOps
  bot: { history: [], platforms: [], response: null, loading: false, error: null },
  botSubTab: 'command', // command | history | platforms
  // 控制面联邦
  federation: { peers: [], devices: [], loading: false, error: null },
  federationSubTab: 'peers', // peers | devices | forward
  // 定时任务
  schedules: { list: [], loading: false, error: null },
  // P3 补齐功能域状态
  // 审批流
  approval: { flows: [], requests: [], pending: [], loading: false, error: null },
  // 密钥管理
  secrets: { status: null, keys: [], loading: false, error: null },
  // Helm 应用商店
  helm: { repos: [], charts: [], releases: [], catalog: [], loading: false, error: null },
  // SSE 连接实例（不直接渲染，仅用于生命周期管理）
  _sse: null,
};


// ============================================================================
// 通用辅助
// ============================================================================

function $(id) { return document.getElementById(id); }

// pageRoot(tab) 返回当前 tab 的根容器。
export function pageRoot(tab) {
  return $('page-' + (tab || state.currentTab));
}

export { state, $ };
